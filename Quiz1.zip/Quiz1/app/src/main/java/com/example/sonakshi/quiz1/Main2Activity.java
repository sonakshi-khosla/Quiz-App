package com.example.sonakshi.quiz1;
//import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
//import android.widget.TextView;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {
    Button b;
    @Override
        protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        b = findViewById(R.id.button);
    }
    public int score=0;
    public void onclick(View v){
        RadioButton sirius = findViewById(R.id.Sirius);
        boolean hasSirius = sirius.isChecked();

        RadioButton prewett = findViewById(R.id.Prewett);
        boolean hasPrewett = prewett.isChecked();

        RadioButton spew = findViewById(R.id.spew);
        boolean hasSpew = spew.isChecked();

        CheckBox quaffle = findViewById(R.id.quaffle);
        boolean hasQuaffle = quaffle.isChecked();

        CheckBox snitch = findViewById(R.id.snitch);
        boolean hasSnitch = snitch.isChecked();

        CheckBox wiffles = findViewById(R.id.wif);
        boolean hasWiffles = wiffles.isChecked();

        EditText nameField =  findViewById(R.id.name_view_text);
        String name = nameField.getText().toString();

        score = calculateScore(hasSirius, hasPrewett, hasSpew, hasQuaffle, hasSnitch, hasWiffles, name);
        String scoreMessage = "Hi! " + " Your score is " + score + " Thanks for playing!";
        Toast.makeText(getApplicationContext(), scoreMessage, Toast.LENGTH_LONG).show();
    }

    private int calculateScore(boolean hasSirius, boolean hasPrewett, boolean hasSpew, boolean hasQuaffle, boolean hasSnitch, boolean hasWiffles, String name){
        int score = 0;
        String nm = "Ariana's corpse";

        if(hasSirius){
            score = score + 1;
        }
        if (hasPrewett){
            score = score + 1;
        }
        if (hasSpew){
            score = score + 1;
        }

        if(name.equalsIgnoreCase(nm)){
            score = score + 1;
        }
        else{
            score = score - 1;
        }
        if (hasQuaffle && hasSnitch && !hasWiffles){
            score = score + 1;
        }
        return score;
    }
}
